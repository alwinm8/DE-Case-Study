/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decasestudy;

/**
 *
 * @author alwinmathew
 */
public class CountSum 
{
    int COUNT;
    String SUM;
    
    public CountSum(int count, String sum)
    {
        this.COUNT = count;
        this.SUM = sum;
    }
 
    //get for count
    //get for sum
    public int getCount()
    {
        return this.COUNT;
    }
    
    public String getSum()
    {
        return this.SUM;
    }

}
